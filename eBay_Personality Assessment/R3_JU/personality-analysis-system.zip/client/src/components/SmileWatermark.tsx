const smileAssetUrl = "/manus-storage/smile-black-transparent_bb9c220a.png";

export default function SmileWatermark() {
  return <img className="smile-watermark" src={smileAssetUrl} alt="" aria-hidden="true" />;
}

export { smileAssetUrl };
