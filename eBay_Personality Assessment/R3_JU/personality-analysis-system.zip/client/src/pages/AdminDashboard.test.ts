import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { buildResultSvg } from "../../../shared/resultVisualization";
import { RESULT_LABELS } from "../../../shared/groupedQuestionnaire";

describe("result visualization encoding", () => {
  it("declares UTF-8 and keeps traditional Chinese labels readable", () => {
    const scores = Object.fromEntries(RESULT_LABELS.map((label) => [label, 5])) as Record<(typeof RESULT_LABELS)[number], number>;
    const svg = buildResultSvg({ id: 7, name: "小安&測試", submitDate: "2026-09-03" }, scores, 50, true, "春日探索室");
    expect(svg.startsWith('<?xml version="1.0" encoding="UTF-8"?>')).toBe(true);
    expect(svg).toContain('xml:lang="zh-Hant"');
    expect(svg).toContain("果斷");
    expect(svg).toContain("特質分析結果");
    expect(svg).toContain("春日探索室 · 測試日期：2026-09-03");
    expect(svg).toContain("<rect x=\"24\" y=\"86\" width=\"270\" height=\"126\"");
    expect(svg).not.toContain("PERSONALITY RESULT");
    expect(svg).not.toContain("八項特質合計");
    expect(svg).not.toContain("驗證通過");
    expect(svg).not.toContain("小安");
  });

  it("exposes an admin-editable branding setting and passes it to the PNG builder", () => {
    const source = readFileSync(new URL("./AdminDashboard.tsx", import.meta.url), "utf8");
    expect(source).toContain("branding.update");
    expect(source).toContain("品牌設定");
    expect(source).toContain("brandName");
    expect(source).toContain("buildResultSvg(detail, scores, total, valid, brandName)");
  });

  it("uses a canvas PNG download flow in the admin result page", () => {
    const source = readFileSync(new URL("./AdminDashboard.tsx", import.meta.url), "utf8");
    expect(source).toContain('canvas.toBlob');
    expect(source).toContain('"image/png"');
    expect(source).toContain('anchor.download = `personality-result-${String(detail.id)}.png`');
  });
});
